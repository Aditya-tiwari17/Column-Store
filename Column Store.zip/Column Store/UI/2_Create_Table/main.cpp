#include <windows.h>
#include<bits/stdc++.h>
#include "C:\Users\AdityaTiw\Desktop\Column Store\UI\2_Create_Table\Table.cpp"
using namespace std;
#define ID_BTN 1
#define ID_TEXTBOX 2
#define ID_column 3
static HWND hwndTextBox,hwndTextBox_column,hwndTextBox_columntype;

Table obj=Table();
FILE *fp;

/* This is where all the input to the window goes to */
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	int i=1;
	
	
	switch(Message) {
		
		/* Upon destruction, tell the main thread to stop */
		case WM_CREATE:{
			// TABLE NAME ENTER
			CreateWindow(TEXT("Static"),TEXT("Table Name "),
			WS_VISIBLE | WS_CHILD ,
			20,50,200,25,hwnd,(HMENU) NULL,NULL,NULL
			);
			hwndTextBox=CreateWindow(TEXT("Edit"),TEXT(""),
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			100,50,200,20,hwnd,(HMENU) ID_TEXTBOX,NULL,NULL
			);
			// COLUMN NAME ENTER
			CreateWindow(TEXT("Static"),TEXT("Column Details "),
			WS_VISIBLE | WS_CHILD ,
			9,150,200,25,hwnd,(HMENU) NULL,NULL,NULL
			);
			CreateWindow(TEXT("Static"),TEXT("Column Name"),
			WS_VISIBLE | WS_CHILD ,
			150,100,250,25,hwnd,(HMENU) NULL,NULL,NULL
			);
			CreateWindow(TEXT("Static"),TEXT("Column Type "),
			WS_VISIBLE | WS_CHILD ,
			350,100,200,25,hwnd,(HMENU) NULL,NULL,NULL
			);
			hwndTextBox_column=CreateWindow(TEXT("Edit"),TEXT(""),
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			100,150,200,20,hwnd,(HMENU) NULL,NULL,NULL
			);
			hwndTextBox_columntype=CreateWindow(TEXT("Edit"),TEXT(""),
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			300,150,200,20,hwnd,(HMENU) NULL,NULL,NULL			);
			
			CreateWindow(TEXT("button"),TEXT("+"),
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			500,150,40,20,hwnd,(HMENU) ID_column,NULL,NULL
			);
			
			CreateWindow(TEXT("button"),TEXT("Click"),
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			100,500,100,25,hwnd,(HMENU) ID_BTN,NULL,NULL
			);
			
			
			break;
		}
		case WM_COMMAND:{
		
			
			// action for default button 
			if(LOWORD(wParam)== ID_BTN){
				int len=GetWindowTextLength(hwndTextBox)+ 1;
				static char title[500];
				
				GetWindowText(hwndTextBox,title,len);
//				SetWindowText(hwnd,title);
				
				obj.display(title);
				string path(title),table_path;
				table_path=path+"/";
				
				path=path+"/Column_Desc.txt";
				fp=fopen(path.c_str(),"a+");
				obj.add_file(fp);
				for(int i=0;i<obj.colname_type.size();i++)
				{
				
					string temp=table_path+obj.colname_type[i].first+".txt";
					MessageBox(hwnd,temp.c_str(),"Table Created Succesfully",MB_OK);
					FILE *fpcol=fopen(temp.c_str(),"r");
					
					fclose(fpcol);
				}
				MessageBox(hwnd,title,"Table Created Succesfully",MB_OK);
			}
			if(LOWORD(wParam)== ID_column){
				i++;
				int len=GetWindowTextLength(hwndTextBox_column)+ 1;
				static char title[500];
				
				GetWindowText(hwndTextBox_column,title,len);
				int len1=GetWindowTextLength(hwndTextBox_columntype)+ 1;
				static char title1[500];
				
				GetWindowText(hwndTextBox_columntype,title1,len1);
				string x(title),y(title1);
				obj.add_column(x,y);
//				MessageBox(hwnd,title,"Message Box",MB_OK);
				string col="";
				for (int i=0;i<obj.colname_type.size();i++)
				{
					if(i==obj.colname_type.size())
					{
						col=col+obj.colname_type[i].first+":"+obj.colname_type[i].second;
					}
					else
					{
							col=col+obj.colname_type[i].first+":"+obj.colname_type[i].second+",";
					}
				}
			
				CreateWindow(TEXT("Edit"),TEXT(col.c_str()),
				WS_VISIBLE | WS_CHILD | WS_BORDER,
				200,250,200,200,hwnd,(HMENU) NULL,NULL,NULL
				);
			
			
			
				
			}
			
			break;
		}
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */

	/* zero out the struct and set the stuff we want to modify */
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
	wc.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Column GUI",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		0, /* x */
		10, /* y */
		1000, /* width */
		700, /* height */
		NULL,NULL,hInstance,NULL);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	/*
		This is the heart of our program where all input is processed and 
		sent to WndProc. Note that GetMessage blocks code flow until it receives something, so
		this loop will not produce unreasonably high CPU usage
	*/
	while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
		TranslateMessage(&msg); /* Translate key codes to chars if present */
		DispatchMessage(&msg); /* Send it to WndProc */
	}
	return msg.wParam;
}
