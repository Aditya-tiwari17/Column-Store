#include<bits/stdc++.h>
#include<dirent.h>
#include<iostream>
#include<stdio.h>
#include <io.h>
using namespace std;

class Table{
	private:
	public:	
		vector<pair<string,string> > colname_type;
		string table_path;
		string table_name;
		

		void add_column(string column_name,string type)
		{
			colname_type.push_back(make_pair(column_name,type));
		
			

		}
		void add_file(FILE *fp)
		{
//			table_path=path+"/"+"Column_Desc.txt";
			
		
			
			for(int i=0;i<colname_type.size();i++)
			{
				
				
				if(i==colname_type.size())
					{
						stringstream ss,ff;
						ss<<colname_type[i].first;
						ff<<colname_type[i].second;
						string a,b;
						a=ss.str();
						
						b=ff.str();
						string final=a+":"+b;
						fputs(final.c_str(),fp);
						
					}
					else
					{
						stringstream ss,ff;
						ss<<colname_type[i].first;
						ff<<colname_type[i].second;
						string a,b;
						a=ss.str();
						b=ff.str();
						string final=a+":"+b+",";
						fputs(final.c_str(),fp);
					}
			}
			fclose(fp);
		}
		
		void display(char *table)
		{
			
			mkdir(table);
			string path(table);
			
			
		}
};


