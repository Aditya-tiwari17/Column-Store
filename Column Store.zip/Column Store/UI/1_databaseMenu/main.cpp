#include <windows.h>
#include<bits/stdc++.h>
#include<dirent.h>
#include <io.h>
using namespace std;
#define ID_CreateBtn 1
#define ID_DeleteBtn 2
#define ID_ShowBtn 3
#define ID_UseBtn 4
#define ID_win2_ShowBtn 1
#define ID_win2_CreateBtn 2
#define ID_win2_DeleteBtn 3
static HWND hwnd, hwnd_create,hwnd_show,hwnd_delete,hwnd_use,hwnd_delete_table;
static HWND hwnd_usedatabase_win;
HINSTANCE hInst;
string database_path="";
string directory_path="Database";

string display_tables(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
	{
		DIR *folder;
	    struct dirent *entry;
	    int files = 0;
		string filename="";
	    folder = opendir(database_path.c_str());
	    if(folder == NULL)
	    {        
	        MessageBox(hwnd,"Unable to read directory","Error",MB_OK);
	        
	    }
	
	    while((entry=readdir(folder)) )
	    {
	        files++;
	        if(files>2)
	        filename=filename+"\n"+entry->d_name;
	        
	    }
	
	    closedir(folder);
	    return filename;
	}
void delete_table(string db_name,HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
	{
		DIR *folder;
	    struct dirent *entry;
		string path=database_path+"/"+db_name;
	    folder = opendir(path.c_str());
	    if(folder==NULL)
	    {
	    	
	    	MessageBox(hwnd,"Table Does Not Exists!!","Error",MB_OK);
        
	       
	    }
	    else
	    {
	    	
	    	if(rmdir( path.c_str() ) != 0 )
	    	MessageBox(hwnd,"Error deleting Table","Error",MB_OK);
   				
			  else
			  MessageBox(hwnd,"Table successfully deleted","Success",MB_OK);
			  
	    	
		}
	}

LRESULT CALLBACK Sub_Window_UseDatabase(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		case WM_CREATE:{
			 
			CreateWindow(TEXT("Static"),TEXT("TABLES MENU "),WS_VISIBLE | WS_CHILD,300,10,200,25,hwnd,(HMENU) NULL,NULL,NULL);
			
			// COLUMN NAME ENTER
			CreateWindow(TEXT("Static"),TEXT("SHOW TABLES "),WS_VISIBLE | WS_CHILD ,9,100,200,20,hwnd,(HMENU) NULL,NULL,NULL);
//			hwnd_show=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,100,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("SHOW TABLES"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,100,200,20,hwnd,(HMENU) ID_win2_ShowBtn,NULL,NULL);
			
			
			CreateWindow(TEXT("Static"),TEXT("CREATE TABLE"),WS_VISIBLE | WS_CHILD ,9,200,200,20,hwnd,(HMENU) NULL,NULL,NULL);
//			hwnd_create=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,200,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("CREATE TABLE"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,200,200,20,hwnd,(HMENU) ID_win2_CreateBtn,NULL,NULL);
			
			CreateWindow(TEXT("Static"),TEXT("DELETE TABLE "),WS_VISIBLE | WS_CHILD ,9,300,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			hwnd_delete_table=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,300,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("DELETE TABLE"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,300,200,20,hwnd,(HMENU) ID_win2_DeleteBtn,NULL,NULL);
			
			CreateWindow(TEXT("Static"),TEXT("RUN QUERY"),WS_VISIBLE | WS_CHILD ,9,400,200,20,hwnd,(HMENU) NULL,NULL,NULL);
//			hwnd_use=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,400,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("RUN QUERY"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,400,200,20,hwnd,(HMENU) ID_UseBtn,NULL,NULL);
			
			
		
			
	
			
			break;
		}
		case WM_COMMAND:{
		if(LOWORD(wParam)==ID_win2_ShowBtn)
			{
				string db_name=display_tables(hwnd,Message,wParam, lParam);
				if(db_name!="")
				MessageBox(hwnd,db_name.c_str(),"Databases",MB_OK);
				else
				MessageBox(hwnd,"Database Empty","Error",MB_OK);
			}
		if(LOWORD(wParam)==ID_win2_DeleteBtn)
			{
				int len=GetWindowTextLength(hwnd_delete_table)+ 1;
				static char title[500];		
				GetWindowText(hwnd_delete_table,title,len);
				string db_name(title);
				if(db_name=="")
				MessageBox(hwnd,"Enter Table Name","Error",MB_OK);
				else
				{
					delete_table(db_name,hwnd,Message,wParam, lParam);
				}
			}
			
			break;
		}
		/* Upon destruction, tell the main thread to stop */
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

void CreateSubWnd(){
WNDCLASSEX wc; /* A properties struct of our window */
/* zero out the struct and set the stuff we want to modify */
memset(&wc,0,sizeof(wc));
wc.cbSize        = sizeof(WNDCLASSEX);
wc.lpfnWndProc   = Sub_Window_UseDatabase; /* This is where we will send messages to */
wc.hInstance     = hInst;
wc.hCursor       = LoadCursor(NULL, IDC_ARROW);

/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
wc.lpszClassName = "SubWindowClass";
wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */

if(!RegisterClassEx(&wc)) {
    MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
    return;
}

hwnd_usedatabase_win = CreateWindowEx(WS_EX_CLIENTEDGE,wc.lpszClassName,"Use Database",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
    CW_USEDEFAULT, /* x */
    CW_USEDEFAULT, /* y */
    640, /* width */
    480, /* height */
    NULL,NULL,hInst,NULL);

if(hwnd_usedatabase_win == NULL) {
    MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
    return;
}
}
/* This is where all the input to the window goes to */

string display_database(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
	{
		DIR *folder;
	    struct dirent *entry;
	    int files = 0;
		string filename="";
	    folder = opendir(directory_path.c_str());
	    if(folder == NULL)
	    {
	        
	        MessageBox(hwnd,"Unable to read directory","Error",MB_OK);
	        
	    }
	
	    while((entry=readdir(folder)) )
	    {
	        files++;
	        if(files>2)
	        filename=filename+"\n"+entry->d_name;
	        
	    }
	
	    closedir(folder);
	    return filename;
	}
void create_database(string db_name,HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
	{
		DIR *folder;
	    struct dirent *entry;
		string path=directory_path+"/"+db_name;
	    folder = opendir(path.c_str());
	    if(folder==NULL)
	    {
	        mkdir(path.c_str());
	        MessageBox(hwnd,"Database Successfully created","Success",MB_OK);
	    }
	    else
	    {
	    	MessageBox(hwnd,"Database Already Exists","Error",MB_OK);
	    	
	    	
		}
	     
	    
		
	}	
	
void delete_database(string db_name,HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
	{
		DIR *folder;
	    struct dirent *entry;
		string path=directory_path+"/"+db_name;
	    folder = opendir(path.c_str());
	    if(folder==NULL)
	    {
	    	
	    	MessageBox(hwnd,"Database Does Not Exists!!","Error",MB_OK);
        
	       
	    }
	    else
	    {
	    	
	    	if(rmdir( path.c_str() ) != 0 )
	    	MessageBox(hwnd,"Error deleting Database","Error",MB_OK);
   				
			  else
			  MessageBox(hwnd,"Database successfully deleted","Success",MB_OK);
			  
	    	
		}
	}
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		case WM_CREATE:{
			// TABLE NAME ENTER
			CreateWindow(TEXT("Static"),TEXT("DATABASE MENU "),WS_VISIBLE | WS_CHILD,300,10,200,25,hwnd,(HMENU) NULL,NULL,NULL);
			
			// COLUMN NAME ENTER
			CreateWindow(TEXT("Static"),TEXT("SHOW DATABASES "),WS_VISIBLE | WS_CHILD ,9,100,200,20,hwnd,(HMENU) NULL,NULL,NULL);
//			hwnd_show=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,100,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("SHOW DATABASES"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,100,200,20,hwnd,(HMENU) ID_ShowBtn,NULL,NULL);
			
			
			CreateWindow(TEXT("Static"),TEXT("CREATE DATABASE"),WS_VISIBLE | WS_CHILD ,9,200,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			hwnd_create=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,200,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("CREATE DATABASE"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,200,200,20,hwnd,(HMENU) ID_CreateBtn,NULL,NULL);
			
			CreateWindow(TEXT("Static"),TEXT("DELETE DATABASE "),WS_VISIBLE | WS_CHILD ,9,300,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			hwnd_delete=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,300,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("DELETE DATABASE"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,300,200,20,hwnd,(HMENU) ID_DeleteBtn,NULL,NULL);
			
			CreateWindow(TEXT("Static"),TEXT("USE DATABASE"),WS_VISIBLE | WS_CHILD ,9,400,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			hwnd_use=CreateWindow(TEXT("Edit"),TEXT(""),WS_VISIBLE | WS_CHILD | WS_BORDER,200,400,200,20,hwnd,(HMENU) NULL,NULL,NULL);
			CreateWindow(TEXT("button"),TEXT("USE DATABASE"),WS_VISIBLE | WS_CHILD | WS_BORDER,400,400,200,20,hwnd,(HMENU) ID_UseBtn,NULL,NULL);
			
			
		
			
	
			
			break;
		}
		case WM_COMMAND:{
		
			
			// action for default button 
			if(LOWORD(wParam)==ID_ShowBtn)
			{
				string db_name=display_database(hwnd,Message,wParam, lParam);
				MessageBox(hwnd,db_name.c_str(),"Databases",MB_OK);
			}
			if(LOWORD(wParam)==ID_CreateBtn)
			{
				int len=GetWindowTextLength(hwnd_create)+ 1;
				static char title[500];		
				GetWindowText(hwnd_create,title,len);
				string db_name(title);
				if(db_name=="")
				MessageBox(hwnd,"Enter Database Name","Error",MB_OK);
				else
				{
					create_database(db_name,hwnd,Message,wParam, lParam);
				}
			}
			if(LOWORD(wParam)==ID_DeleteBtn)
			{
				int len=GetWindowTextLength(hwnd_delete)+ 1;
				static char title[500];		
				GetWindowText(hwnd_delete,title,len);
				string db_name(title);
				if(db_name=="")
				MessageBox(hwnd,"Enter Database Name","Error",MB_OK);
				else
				{
				delete_database(db_name,hwnd,Message,wParam, lParam);
				}
			}
			if(LOWORD(wParam)==ID_UseBtn)
			{
				int len=GetWindowTextLength(hwnd_use)+ 1;
				static char title[500];		
				GetWindowText(hwnd_use,title,len);
				string db_name(title);
				if(db_name=="")
				MessageBox(hwnd,"Enter Database Name","Error",MB_OK);
				else
				{
					CloseWindow(hwnd);
					CreateSubWnd();
        			ShowWindow(hwnd_usedatabase_win, SW_SHOW);
					database_path=directory_path+"/"+db_name;
					}
				}
			
			
			break;
		}
		/* Upon destruction, tell the main thread to stop */
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

void CreateMainWnd(){

WNDCLASSEX wc; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */

	/* zero out the struct and set the stuff we want to modify */
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc.hInstance	 = hInst;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Database Menu",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		300, /* x */
		10, /* y */
		800, /* width */
		600, /* height */
		NULL,NULL,hInst,NULL);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return;
	}

	/*
		This is the heart of our program where all input is processed and 
		sent to WndProc. Note that GetMessage blocks code flow until it receives something, so
		this loop will not produce unreasonably high CPU usage
	*/
	while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
		TranslateMessage(&msg); /* Translate key codes to chars if present */
		DispatchMessage(&msg); /* Send it to WndProc */
	}
}

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	MSG msg; /* A temporary location for all messages */
hInst = hInstance;
CreateMainWnd();
CreateSubWnd();
ShowWindow(hwnd, nCmdShow);
ShowWindow(hwnd_usedatabase_win, SW_HIDE);
while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
    TranslateMessage(&msg); /* Translate key codes to chars if present */
    DispatchMessage(&msg); /* Send it to WndProc */
}
return msg.wParam;
}
